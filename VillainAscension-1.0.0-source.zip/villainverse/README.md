# Villain Ascension

Standalone Fabric mod project for **Minecraft 1.21.1**, **Fabric Loader 0.16.5+**, and **Java 21**.

This is a new mod identity (`villain_ascension`), independent of the former `villainverse` mod ID. The supplied starter project carries forward the existing playable-persona and Infinity Stone ability code as a starting foundation. It is not yet the complete 28-character overhaul described in the design brief; additional characters, custom models/animations, HUD, and boss AI must be implemented and tested in subsequent phases.

## Build a Modrinth-uploadable JAR

1. Install a 64-bit Java 21 JDK.
2. Install Gradle 8.8 or newer (Gradle 8.10.2 recommended).
3. Open a terminal in this folder.
4. Run `gradle clean build` (Windows: `gradle.bat clean build` if using a local Gradle installation).
5. Upload `build/libs/villain-ascension-1.0.0.jar` to Modrinth as a Fabric mod for Minecraft 1.21.1.

The `build.gradle` file uses Fabric Loom and the project pins Minecraft/Yarn/Fabric API versions in `gradle.properties`. The first build needs internet access to resolve Gradle and Fabric dependencies.

## In-game controls

- `/villain <persona>` — select a currently implemented persona.
- `/villain stones` — receive the Infinity Stone items.
- `/villain none` — clear the selected persona.
- `V` — use selected ability.
- `C` — cycle abilities.

## Current implementation status

The inherited starter implementation contains Infinity Ultron, Joker, Bane, Batman Who Laughs, Kang, and AM persona entries, plus Infinity Stone items and a server-authoritative ability packet. The project has been renamed as a separate mod. It still requires a full compile and in-game validation before it should be treated as a tested release. This environment did not have Gradle installed and could not reach the Gradle distribution host, so a compiled JAR could not be produced here.
