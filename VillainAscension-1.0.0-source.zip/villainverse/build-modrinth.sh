#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v gradle >/dev/null 2>&1; then
  echo "Gradle is required. Install Gradle 8.10.2+ and Java 21, then rerun this script." >&2
  exit 1
fi
gradle clean build
printf '\nBuilt mod JAR(s):\n'
find build/libs -maxdepth 1 -type f -name '*.jar' -print
