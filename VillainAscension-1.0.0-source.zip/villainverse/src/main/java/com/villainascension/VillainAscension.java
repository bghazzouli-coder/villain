package com.villainascension;
import com.mojang.brigadier.arguments.StringArgumentType;
import java.util.*;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.command.CommandSource;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;

public class VillainAscension implements ModInitializer {
    public static final String ID = "villain_ascension";
    private static final Map<UUID, Persona> PERSONA = new HashMap<>();
    private static final Map<UUID, Integer> SELECTED = new HashMap<>();
    private static final Map<String, Long> COOLDOWN = new HashMap<>();

    @Override public void onInitialize() {
        ModItems.register();
        PayloadTypeRegistry.playC2S().register(AbilityPayload.ID, AbilityPayload.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(AbilityPayload.ID, (payload, ctx) -> {
            ServerPlayerEntity p = ctx.player();
            if (payload.action() == 0) useAbility(p); else cycle(p);
        });
        CommandRegistrationCallback.EVENT.register((d, reg, env) -> d.register(CommandManager.literal("villain")
            .then(CommandManager.literal("stones").executes(c -> { ModItems.giveAll(c.getSource().getPlayerOrThrow()); return 1; }))
            .then(CommandManager.literal("none").executes(c -> { setPersona(c.getSource().getPlayerOrThrow(), null); return 1; }))
            .then(CommandManager.argument("persona", StringArgumentType.word())
                .suggests((c, b) -> CommandSource.suggestMatching(Arrays.stream(Persona.values()).map(Persona::id), b))
                .executes(c -> {
                    Persona p = Persona.byId(StringArgumentType.getString(c, "persona"));
                    if (p == null) { c.getSource().sendError(Text.literal("Unknown persona")); return 0; }
                    setPersona(c.getSource().getPlayerOrThrow(), p); return 1;
                }))));
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            int t = server.getTicks();
            for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
                Persona ps = PERSONA.get(p.getUuid()); if (ps == null) continue;
                if (t % 5 == 0) p.getServerWorld().spawnParticles(ps.aura, p.getX(), p.getY() + 1, p.getZ(), 6, 0.5, 0.9, 0.5, 0.03);
                if (t % 40 == 0) {
                    for (Persona.Buff b : ps.buffs) p.addStatusEffect(new StatusEffectInstance(b.effect(), 100, b.amp(), true, false));
                    if (ps.flight && !p.getAbilities().allowFlying) { p.getAbilities().allowFlying = true; p.sendAbilitiesUpdate(); }
                }
            }
        });
    }

    public static void setPersona(ServerPlayerEntity p, Persona ps) {
        UUID id = p.getUuid();
        if (ps == null) {
            PERSONA.remove(id);
            if (!p.isCreative() && !p.isSpectator()) { p.getAbilities().allowFlying = false; p.getAbilities().flying = false; p.sendAbilitiesUpdate(); }
            p.sendMessage(Text.literal("You return to normal."), true); return;
        }
        PERSONA.put(id, ps); SELECTED.put(id, 0);
        p.sendMessage(Text.literal("You are now " + ps.display + ".  [V] use ability, [C] cycle"), true);
        Fx.sphere(p.getServerWorld(), p.getPos().add(0, 1, 0), 3, ps.aura, 120);
    }
    private static void cycle(ServerPlayerEntity p) {
        Persona ps = PERSONA.get(p.getUuid()); if (ps == null) return;
        int i = (SELECTED.getOrDefault(p.getUuid(), 0) + 1) % ps.abilities.size(); SELECTED.put(p.getUuid(), i);
        p.sendMessage(Text.literal("Selected: " + ps.abilities.get(i).name()), true);
    }
    private static void useAbility(ServerPlayerEntity p) {
        Persona ps = PERSONA.get(p.getUuid()); if (ps == null) { p.sendMessage(Text.literal("Use /villain <persona> first."), true); return; }
        Ability ab = ps.abilities.get(SELECTED.getOrDefault(p.getUuid(), 0) % ps.abilities.size());
        long now = p.getServerWorld().getTime(); String key = p.getUuid() + ":" + ab.name();
        Long until = COOLDOWN.get(key);
        if (until != null && now < until) { p.sendMessage(Text.literal(ab.name() + " recharging: " + (until - now) / 20 + "s"), true); return; }
        net.minecraft.util.math.Vec3d before = p.getPos();
        ab.run().accept(p); COOLDOWN.put(key, now + ab.cooldown());
        if (ab != Abilities.REWIND) Fx.ANCHOR.put(p.getUuid(), before);
        p.sendMessage(Text.literal(ab.name()), true);
    }
}
