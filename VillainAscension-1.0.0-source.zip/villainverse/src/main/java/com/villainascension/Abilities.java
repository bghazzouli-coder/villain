package com.villainascension;
import java.util.*;
import java.util.function.Consumer;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.entity.AreaEffectCloudEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.*;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.*;

public final class Abilities {
    private Abilities() {}
    private static Ability a(String n, int cd, Consumer<ServerPlayerEntity> r) { return new Ability(n, cd, r); }
    private static StatusEffectInstance fx(net.minecraft.registry.entry.RegistryEntry<StatusEffect> e, int ticks, int amp) { return new StatusEffectInstance(e, ticks, amp); }
    private static final Random RND = new Random();

    // ===== INFINITY STONES =====
    public static final Ability SPACE = a("Space Stone: Rift Step", 30, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d to = Fx.target(p, 60);
        Fx.beam(w, p.getEyePos(), to, ParticleTypes.REVERSE_PORTAL);
        p.requestTeleport(to.x, to.y + 0.1, to.z);
        Fx.sphere(w, to, 2.5, ParticleTypes.PORTAL, 80); Fx.sound(w, to, SoundEvents.ENTITY_ENDERMAN_TELEPORT);
    });
    public static final Ability MIND = a("Mind Stone: Psychic Overload", 120, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 24)) {
            e.addStatusEffect(fx(StatusEffects.GLOWING, 400, 0)); e.addStatusEffect(fx(StatusEffects.WEAKNESS, 400, 2));
            e.addStatusEffect(fx(StatusEffects.NAUSEA, 200, 0)); Fx.hurt(p, e, 6);
            w.spawnParticles(ParticleTypes.ENCHANT, e.getX(), e.getEyeY(), e.getZ(), 40, 0.4, 0.6, 0.4, 0.6);
        }
        Fx.sphere(w, p.getPos().add(0, 1, 0), 6, ParticleTypes.ENCHANT, 150);
    });
    public static final Ability REALITY = a("Reality Stone: Rewrite", 160, p -> {
        ServerWorld w = p.getServerWorld(); BlockPos c = BlockPos.ofFloored(Fx.target(p, 50));
        Block[] pool = { Blocks.CRYING_OBSIDIAN, Blocks.AMETHYST_BLOCK, Blocks.MAGMA_BLOCK, Blocks.GLOWSTONE, Blocks.SLIME_BLOCK, Blocks.SCULK, Blocks.RED_NETHER_BRICKS };
        int r = 6;
        for (BlockPos bp : BlockPos.iterate(c.add(-r, -r, -r), c.add(r, r, r))) {
            if (bp.getSquaredDistance(c) > r * r) continue;
            BlockState s = w.getBlockState(bp);
            if (!s.isAir() && s.getHardness(w, bp) >= 0) w.setBlockState(bp, pool[RND.nextInt(pool.length)].getDefaultState());
        }
        Fx.sphere(w, Vec3d.ofCenter(c), r, ParticleTypes.FLAME, 200); Fx.sound(w, Vec3d.ofCenter(c), SoundEvents.BLOCK_END_PORTAL_SPAWN);
    });
    public static final Ability POWER = a("Power Stone: Annihilation", 100, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d from = p.getEyePos(), to = Fx.target(p, 70);
        Fx.beam(w, from, to, ParticleTypes.DRAGON_BREATH); Fx.beamDamage(p, from, to, 30);
        Fx.blast(w, p, to, 7f); w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, to.x, to.y, to.z, 3, 1.5, 1.5, 1.5, 0);
    });
    public static final Ability TIME = a("Time Stone: Stasis", 200, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 25)) { e.addStatusEffect(fx(StatusEffects.SLOWNESS, 200, 9)); e.addStatusEffect(fx(StatusEffects.WEAKNESS, 200, 5)); e.addStatusEffect(fx(StatusEffects.MINING_FATIGUE, 200, 5)); }
        Fx.sphere(w, p.getPos().add(0, 1, 0), 10, ParticleTypes.CLOUD, 250); Fx.sphere(w, p.getPos().add(0, 1, 0), 10, ParticleTypes.END_ROD, 100);
        Fx.sound(w, p.getPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE);
    });
    public static final Ability SOUL = a("Soul Stone: Soul Drain", 120, p -> {
        ServerWorld w = p.getServerWorld(); float total = 0;
        for (LivingEntity e : Fx.nearby(p, 14)) {
            Fx.hurt(p, e, 8); total += 4; Fx.beam(w, e.getEyePos(), p.getEyePos(), ParticleTypes.SOUL);
        }
        p.heal(total); p.addStatusEffect(fx(StatusEffects.ABSORPTION, 400, 4));
        Fx.sphere(w, p.getPos().add(0, 1, 0), 3, ParticleTypes.SOUL_FIRE_FLAME, 80);
    });

    // ===== INFINITY ULTRON =====
    public static final Ability ULTRON_BEAM = a("Ultron: Annihilation Beam", 30, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d from = p.getEyePos(), to = Fx.target(p, 80);
        Fx.beam(w, from, to, ParticleTypes.END_ROD); Fx.beam(w, from, to, ParticleTypes.ELECTRIC_SPARK);
        Fx.beamDamage(p, from, to, 25); Fx.blast(w, p, to, 4f); Fx.sound(w, from, SoundEvents.ENTITY_WARDEN_SONIC_BOOM);
    });
    public static final Ability POWER_NOVA = a("Ultron: Power Nova", 200, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d c = p.getPos();
        for (LivingEntity e : Fx.nearby(p, 18)) { Fx.hurt(p, e, 40); Fx.push(e, e.getPos().subtract(c).normalize().multiply(2.5).add(0, 0.8, 0)); }
        for (int i = 0; i < 8; i++) { double ang = i * Math.PI / 4; Fx.blast(w, p, c.add(Math.cos(ang) * 9, 0, Math.sin(ang) * 9), 3f); }
        for (int r = 2; r <= 16; r += 2) Fx.sphere(w, c.add(0, 1, 0), r, ParticleTypes.END_ROD, 120);
        w.spawnParticles(ParticleTypes.SONIC_BOOM, c.x, c.y + 1, c.z, 1, 0, 0, 0, 0); Fx.sound(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value());
    });
    public static final Ability SENTINEL_STORM = a("Ultron: Sentinel Storm", 160, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 60);
        for (int i = 0; i < 12; i++) {
            Vec3d o = t.add(RND.nextGaussian() * 7, 0, RND.nextGaussian() * 7);
            Fx.bolt(w, o, false); Fx.blast(w, p, o, 2.5f);
            w.spawnParticles(ParticleTypes.ELECTRIC_SPARK, o.x, o.y + 1, o.z, 30, 0.5, 1.5, 0.5, 0.3);
        }
    });

    // ===== JOKER =====
    public static final Ability LAUGH_GAS = a("Joker: Laughing Gas", 100, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 30);
        AreaEffectCloudEntity c = new AreaEffectCloudEntity(w, t.x, t.y, t.z);
        c.setRadius(7f); c.setDuration(240); c.setOwner(p); c.setParticleType(ParticleTypes.HAPPY_VILLAGER);
        c.addEffect(fx(StatusEffects.POISON, 120, 2)); c.addEffect(fx(StatusEffects.NAUSEA, 200, 0)); c.addEffect(fx(StatusEffects.WEAKNESS, 200, 1));
        w.spawnEntity(c);
    });
    public static final Ability JOKER_BOMBS = a("Joker: Party Favors", 80, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 40);
        for (int i = 0; i < 7; i++) {
            Vec3d o = t.add(RND.nextGaussian() * 5, 0, RND.nextGaussian() * 5); Fx.blast(w, p, o, 2f);
            w.spawnParticles(ParticleTypes.FIREWORK, o.x, o.y + 1, o.z, 40, 0.5, 0.8, 0.5, 0.2);
        }
    });
    public static final Ability PUNCHLINE = a("Joker: The Punchline", 220, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 50);
        for (int i = 0; i < 9; i++) Fx.bolt(w, t.add(RND.nextGaussian() * 6, 0, RND.nextGaussian() * 6), false);
        Fx.sphere(w, t, 6, ParticleTypes.HAPPY_VILLAGER, 150);
    });

    // ===== BANE =====
    public static final Ability VENOM = a("Bane: Venom Surge", 300, p -> {
        p.addStatusEffect(fx(StatusEffects.STRENGTH, 600, 4)); p.addStatusEffect(fx(StatusEffects.RESISTANCE, 600, 2)); p.addStatusEffect(fx(StatusEffects.SPEED, 600, 1));
        Fx.push(p, p.getRotationVec(1f).multiply(1.6).add(0, 0.9, 0)); p.addStatusEffect(fx(StatusEffects.SLOW_FALLING, 40, 0));
        Fx.sphere(p.getServerWorld(), p.getPos().add(0, 1, 0), 1.5, ParticleTypes.SCULK_SOUL, 60);
    });
    public static final Ability GROUND_POUND = a("Bane: Break The City", 160, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d c = p.getPos();
        p.addStatusEffect(fx(StatusEffects.SLOW_FALLING, 80, 0));
        for (LivingEntity e : Fx.nearby(p, 10)) { Fx.hurt(p, e, 25); Fx.push(e, e.getPos().subtract(c).normalize().multiply(1.8).add(0, 0.6, 0)); }
        Fx.crater(w, c.add(0, -1, 0), 4);
        for (int r = 1; r <= 10; r += 3) Fx.sphere(w, c.add(0, 0.3, 0), r, ParticleTypes.CAMPFIRE_COSY_SMOKE, 60);
        w.spawnParticles(ParticleTypes.EXPLOSION_EMITTER, c.x, c.y, c.z, 4, 2, 0.2, 2, 0); Fx.sound(w, c, SoundEvents.ENTITY_GENERIC_EXPLODE.value());
    });
    public static final Ability BACKBREAKER = a("Bane: Backbreaker", 100, p -> {
        LivingEntity t = Fx.lookTarget(p, 8); if (t == null) { p.sendMessage(net.minecraft.text.Text.literal("No target in reach"), true); return; }
        Fx.hurt(p, t, 40); t.addStatusEffect(fx(StatusEffects.SLOWNESS, 200, 3)); t.addStatusEffect(fx(StatusEffects.WEAKNESS, 200, 3));
        p.getServerWorld().spawnParticles(ParticleTypes.CRIT, t.getX(), t.getBodyY(0.5), t.getZ(), 60, 0.4, 0.6, 0.4, 0.5);
    });

    // ===== BATMAN WHO LAUGHS =====
    public static final Ability DARK_BEAM = a("BWL: Dark Multiverse Beam", 40, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d from = p.getEyePos(), to = Fx.target(p, 60);
        Fx.beam(w, from, to, ParticleTypes.SOUL_FIRE_FLAME); Fx.beam(w, from, to, ParticleTypes.SQUID_INK);
        Fx.beamDamage(p, from, to, 20);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(to, to).expand(4), x -> x != p)) { e.addStatusEffect(fx(StatusEffects.WITHER, 160, 2)); e.addStatusEffect(fx(StatusEffects.DARKNESS, 200, 0)); }
        Fx.sphere(w, to, 4, ParticleTypes.SCULK_SOUL, 100);
    });
    public static final Ability INFECTION = a("BWL: Infection", 180, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 14)) { e.addStatusEffect(fx(StatusEffects.POISON, 200, 2)); e.addStatusEffect(fx(StatusEffects.WITHER, 200, 1)); e.addStatusEffect(fx(StatusEffects.GLOWING, 300, 0)); }
        for (int r = 2; r <= 14; r += 4) Fx.sphere(w, p.getPos().add(0, 1, 0), r, ParticleTypes.SQUID_INK, 100);
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_WITHER_SPAWN);
    });
    public static final Ability VOID_RIFT = a("BWL: Void Rift", 200, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 30);
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(t, t).expand(20), x -> x != p)) {
            Fx.push(e, t.subtract(e.getPos()).normalize().multiply(1.3)); Fx.hurt(p, e, 10);
        }
        Fx.sphere(w, t, 3, ParticleTypes.PORTAL, 200); Fx.sphere(w, t, 8, ParticleTypes.REVERSE_PORTAL, 200);
    });

    // ===== KANG THE CONQUEROR =====
    public static final Ability KANG_STEP = a("Kang: Temporal Step", 30, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d to = Fx.target(p, 45);
        Fx.beam(w, p.getEyePos(), to, ParticleTypes.ELECTRIC_SPARK); p.requestTeleport(to.x, to.y + 0.1, to.z);
        Fx.sphere(w, to, 2, ParticleTypes.END_ROD, 60);
    });
    public static final Ability TEMPORAL_PULSE = a("Kang: Temporal Pulse", 160, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 16)) { Fx.hurt(p, e, 12); e.addStatusEffect(fx(StatusEffects.SLOWNESS, 160, 6)); e.addStatusEffect(fx(StatusEffects.MINING_FATIGUE, 160, 3)); }
        for (int r = 2; r <= 16; r += 3) Fx.sphere(w, p.getPos().add(0, 1, 0), r, ParticleTypes.ELECTRIC_SPARK, 100);
        Fx.blast(w, p, Fx.target(p, 30), 3f);
    });
    public static final Ability REWIND = a("Kang: Chrono Rewind", 200, p -> {
        Vec3d back = Fx.ANCHOR.get(p.getUuid()); if (back == null) { p.sendMessage(net.minecraft.text.Text.literal("No timeline to return to"), true); return; }
        ServerWorld w = p.getServerWorld(); Fx.sphere(w, p.getPos().add(0, 1, 0), 2, ParticleTypes.REVERSE_PORTAL, 80);
        p.requestTeleport(back.x, back.y, back.z); p.heal(10); Fx.sphere(w, back.add(0, 1, 0), 2, ParticleTypes.REVERSE_PORTAL, 80);
    });

    // ===== AM =====
    public static final Ability HATE_PULSE = a("AM: Hate Pulse", 140, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 22)) { Fx.hurt(p, e, 20); e.addStatusEffect(fx(StatusEffects.BLINDNESS, 200, 0)); e.addStatusEffect(fx(StatusEffects.NAUSEA, 300, 0)); e.addStatusEffect(fx(StatusEffects.DARKNESS, 300, 0)); }
        for (int r = 2; r <= 22; r += 4) Fx.sphere(w, p.getPos().add(0, 1, 0), r, ParticleTypes.SOUL_FIRE_FLAME, 120);
        Fx.sound(w, p.getPos(), SoundEvents.ENTITY_WARDEN_ROAR);
    });
    public static final Ability HELLFIRE = a("AM: Hellfire Rain", 200, p -> {
        ServerWorld w = p.getServerWorld(); Vec3d t = Fx.target(p, 50);
        for (int i = 0; i < 14; i++) {
            Vec3d o = t.add(RND.nextGaussian() * 8, 0, RND.nextGaussian() * 8);
            w.createExplosion(p, o.x, o.y, o.z, 2.5f, true, World_TNT());
            Fx.bolt(w, o, true); w.spawnParticles(ParticleTypes.LAVA, o.x, o.y + 1, o.z, 20, 0.6, 1, 0.6, 0);
        }
        for (LivingEntity e : w.getEntitiesByClass(LivingEntity.class, new Box(t, t).expand(10), x -> x != p)) e.setOnFireFor(10);
    });
    public static final Ability MIND_CRUSH = a("AM: Mind Crush", 100, p -> {
        LivingEntity t = Fx.lookTarget(p, 45); if (t == null) { p.sendMessage(net.minecraft.text.Text.literal("No target in sight"), true); return; }
        ServerWorld w = p.getServerWorld(); Fx.beam(w, p.getEyePos(), t.getEyePos(), ParticleTypes.SCULK_SOUL);
        Fx.hurt(p, t, 60); t.addStatusEffect(fx(StatusEffects.WITHER, 200, 3)); t.addStatusEffect(fx(StatusEffects.BLINDNESS, 200, 0));
        w.spawnParticles(ParticleTypes.SOUL, t.getX(), t.getEyeY(), t.getZ(), 80, 0.5, 0.5, 0.5, 0.3);
    });
    public static final Ability TORMENT = a("AM: Eternal Torment", 300, p -> {
        ServerWorld w = p.getServerWorld();
        for (LivingEntity e : Fx.nearby(p, 28)) { e.addStatusEffect(fx(StatusEffects.WITHER, 400, 2)); e.addStatusEffect(fx(StatusEffects.POISON, 400, 1)); e.addStatusEffect(fx(StatusEffects.GLOWING, 400, 0)); e.setOnFireFor(8); Fx.bolt(w, e.getPos(), false); }
    });
    private static net.minecraft.world.World.ExplosionSourceType World_TNT() { return net.minecraft.world.World.ExplosionSourceType.TNT; }
}
