package com.villainascension;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class VillainAscensionClient implements ClientModInitializer {
    @Override public void onInitializeClient() {
        KeyBinding use = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.villain_ascension.use", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, "key.categories.villain_ascension"));
        KeyBinding cycle = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.villain_ascension.cycle", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_C, "key.categories.villain_ascension"));
        ClientTickEvents.END_CLIENT_TICK.register(c -> {
            while (use.wasPressed()) ClientPlayNetworking.send(new AbilityPayload(0));
            while (cycle.wasPressed()) ClientPlayNetworking.send(new AbilityPayload(1));
        });
    }
}
