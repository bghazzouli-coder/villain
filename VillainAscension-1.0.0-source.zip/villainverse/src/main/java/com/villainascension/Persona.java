package com.villainascension;
import java.util.List;
import net.minecraft.entity.effect.*;
import net.minecraft.particle.*;
import net.minecraft.registry.entry.RegistryEntry;

public enum Persona {
    INFINITY_ULTRON("Infinity Ultron", ParticleTypes.END_ROD, true,
        new Buff[]{ b(StatusEffects.RESISTANCE, 3), b(StatusEffects.STRENGTH, 4), b(StatusEffects.SPEED, 2), b(StatusEffects.REGENERATION, 2), b(StatusEffects.FIRE_RESISTANCE, 0) },
        List.of(Abilities.ULTRON_BEAM, Abilities.POWER_NOVA, Abilities.SENTINEL_STORM, Abilities.SPACE, Abilities.REALITY, Abilities.TIME, Abilities.SOUL, Abilities.POWER, Abilities.MIND)),
    JOKER("The Joker", ParticleTypes.HAPPY_VILLAGER, false,
        new Buff[]{ b(StatusEffects.SPEED, 1), b(StatusEffects.RESISTANCE, 1), b(StatusEffects.JUMP_BOOST, 1) },
        List.of(Abilities.LAUGH_GAS, Abilities.JOKER_BOMBS, Abilities.PUNCHLINE)),
    BANE("Bane", ParticleTypes.SCULK_SOUL, false,
        new Buff[]{ b(StatusEffects.STRENGTH, 3), b(StatusEffects.RESISTANCE, 2), b(StatusEffects.HEALTH_BOOST, 4) },
        List.of(Abilities.VENOM, Abilities.GROUND_POUND, Abilities.BACKBREAKER)),
    BATMAN_WHO_LAUGHS("The Batman Who Laughs", ParticleTypes.SQUID_INK, false,
        new Buff[]{ b(StatusEffects.STRENGTH, 2), b(StatusEffects.RESISTANCE, 2), b(StatusEffects.NIGHT_VISION, 0), b(StatusEffects.SPEED, 1) },
        List.of(Abilities.DARK_BEAM, Abilities.INFECTION, Abilities.VOID_RIFT)),
    KANG("Kang the Conqueror", ParticleTypes.ELECTRIC_SPARK, true,
        new Buff[]{ b(StatusEffects.RESISTANCE, 2), b(StatusEffects.SPEED, 1), b(StatusEffects.REGENERATION, 1) },
        List.of(Abilities.KANG_STEP, Abilities.TEMPORAL_PULSE, Abilities.REWIND)),
    AM("AM", ParticleTypes.SOUL_FIRE_FLAME, true,
        new Buff[]{ b(StatusEffects.RESISTANCE, 3), b(StatusEffects.STRENGTH, 3), b(StatusEffects.FIRE_RESISTANCE, 0), b(StatusEffects.NIGHT_VISION, 0) },
        List.of(Abilities.HATE_PULSE, Abilities.HELLFIRE, Abilities.MIND_CRUSH, Abilities.TORMENT));

    public record Buff(RegistryEntry<StatusEffect> effect, int amp) {}
    private static Buff b(RegistryEntry<StatusEffect> e, int a) { return new Buff(e, a); }

    public final String display; public final ParticleEffect aura; public final boolean flight; public final Buff[] buffs; public final List<Ability> abilities;
    Persona(String d, ParticleEffect a, boolean f, Buff[] bf, List<Ability> ab) { display = d; aura = a; flight = f; buffs = bf; abilities = ab; }
    public String id() { return name().toLowerCase(); }
    public static Persona byId(String s) { for (Persona p : values()) if (p.id().equals(s)) return p; return null; }
}
