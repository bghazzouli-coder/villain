package com.villainascension;
import java.util.Set;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.*;
import net.minecraft.world.World;

public class GauntletItem extends Item {
    public GauntletItem() { super(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof()); }
    @Override public boolean hasGlint(ItemStack s) { return true; }
    @Override public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        if (!w.isClient && p instanceof ServerPlayerEntity sp) {
            for (Item stone : ModItems.STONES) if (!sp.getInventory().containsAny(Set.of(stone))) {
                sp.sendMessage(Text.literal("The gauntlet needs all six Infinity Stones in your inventory."), true);
                return TypedActionResult.fail(p.getStackInHand(h));
            }
            ServerWorld sw = sp.getServerWorld(); int n = 0;
            for (LivingEntity e : sw.getEntitiesByClass(HostileEntity.class, sp.getBoundingBox().expand(48), x -> true)) {
                if (sw.random.nextBoolean()) { sw.spawnParticles(ParticleTypes.ASH, e.getX(), e.getY() + 1, e.getZ(), 80, 0.5, 1, 0.5, 0.1); e.kill(); n++; }
            }
            sw.spawnParticles(ParticleTypes.FLASH, sp.getX(), sp.getEyeY(), sp.getZ(), 1, 0, 0, 0, 0);
            sp.sendMessage(Text.literal("Snap. " + n + " hostile mobs turned to dust."), true);
            p.getItemCooldownManager().set(this, 600);
        }
        return TypedActionResult.success(p.getStackInHand(h));
    }
}
