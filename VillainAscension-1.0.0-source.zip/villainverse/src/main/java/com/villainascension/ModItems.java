package com.villainascension;
import java.util.List;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.*;
import net.minecraft.registry.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class ModItems {
    private static Item reg(String id, Item i) { return Registry.register(Registries.ITEM, Identifier.of(VillainAscension.ID, id), i); }
    public static final Item SPACE_STONE = reg("space_stone", new StoneItem(Abilities.SPACE));
    public static final Item MIND_STONE = reg("mind_stone", new StoneItem(Abilities.MIND));
    public static final Item REALITY_STONE = reg("reality_stone", new StoneItem(Abilities.REALITY));
    public static final Item POWER_STONE = reg("power_stone", new StoneItem(Abilities.POWER));
    public static final Item TIME_STONE = reg("time_stone", new StoneItem(Abilities.TIME));
    public static final Item SOUL_STONE = reg("soul_stone", new StoneItem(Abilities.SOUL));
    public static final Item GAUNTLET = reg("infinity_gauntlet", new GauntletItem());
    public static final List<Item> STONES = List.of(SPACE_STONE, MIND_STONE, REALITY_STONE, POWER_STONE, TIME_STONE, SOUL_STONE);

    public static void register() {
        Registry.register(Registries.ITEM_GROUP, Identifier.of(VillainAscension.ID, "main"), FabricItemGroup.builder()
            .icon(() -> new ItemStack(GAUNTLET)).displayName(Text.translatable("itemGroup.villain_ascension"))
            .entries((ctx, out) -> { out.add(GAUNTLET); STONES.forEach(out::add); }).build());
    }
    public static void giveAll(ServerPlayerEntity p) {
        p.giveItemStack(new ItemStack(GAUNTLET)); STONES.forEach(s -> p.giveItemStack(new ItemStack(s)));
    }
}
