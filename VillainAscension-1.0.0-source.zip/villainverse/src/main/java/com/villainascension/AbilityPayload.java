package com.villainascension;
import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.codec.PacketCodecs;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;
/** action 0 = use selected ability, 1 = cycle ability */
public record AbilityPayload(int action) implements CustomPayload {
    public static final Id<AbilityPayload> ID = new Id<>(Identifier.of(VillainAscension.ID, "ability"));
    public static final PacketCodec<RegistryByteBuf, AbilityPayload> CODEC =
        PacketCodec.tuple(PacketCodecs.VAR_INT, AbilityPayload::action, AbilityPayload::new);
    @Override public Id<? extends CustomPayload> getId() { return ID; }
}
