package com.villainascension;
import java.util.*;
import net.minecraft.block.*;
import net.minecraft.entity.*;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.LightningEntity;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.*;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.*;
import net.minecraft.world.World;

/** Shared effect + targeting helpers. */
public final class Fx {
    public static final Map<UUID, Vec3d> ANCHOR = new HashMap<>();
    private Fx() {}

    public static Vec3d target(ServerPlayerEntity p, double range) {
        HitResult h = p.raycast(range, 1f, false);
        return h.getPos();
    }
    public static LivingEntity lookTarget(ServerPlayerEntity p, double range) {
        Vec3d look = p.getRotationVec(1f); LivingEntity best = null; double bd = 1e9;
        for (LivingEntity e : p.getServerWorld().getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(range), x -> x != p)) {
            Vec3d to = e.getEyePos().subtract(p.getEyePos()); double d = to.length();
            if (d > range || to.normalize().dotProduct(look) < 0.9) continue;
            if (d < bd) { bd = d; best = e; }
        }
        return best;
    }
    public static List<LivingEntity> nearby(ServerPlayerEntity p, double r) {
        return p.getServerWorld().getEntitiesByClass(LivingEntity.class, p.getBoundingBox().expand(r), e -> e != p && e.squaredDistanceTo(p) <= r * r);
    }
    public static void hurt(ServerPlayerEntity p, LivingEntity e, float amt) {
        e.damage(p.getDamageSources().playerAttack(p), amt);
    }
    public static void push(Entity e, Vec3d v) {
        e.setVelocity(e.getVelocity().add(v)); e.velocityModified = true;
        if (e instanceof ServerPlayerEntity sp) sp.networkHandler.sendPacket(new EntityVelocityUpdateS2CPacket(sp));
    }
    public static void beam(ServerWorld w, Vec3d from, Vec3d to, ParticleEffect pe) {
        Vec3d d = to.subtract(from); double len = d.length(); Vec3d s = d.normalize().multiply(0.5);
        for (int i = 0; i < len / 0.5; i++) {
            Vec3d c = from.add(s.multiply(i));
            w.spawnParticles(pe, c.x, c.y, c.z, 2, 0.04, 0.04, 0.04, 0.0);
        }
    }
    public static void beamDamage(ServerPlayerEntity p, Vec3d from, Vec3d to, float dmg) {
        ServerWorld w = p.getServerWorld(); Vec3d d = to.subtract(from);
        Vec3d s = d.normalize(); Set<LivingEntity> hit = new HashSet<>();
        for (int i = 0; i < d.length(); i++) {
            Vec3d c = from.add(s.multiply(i));
            hit.addAll(w.getEntitiesByClass(LivingEntity.class, new Box(c, c).expand(1.5), e -> e != p));
        }
        for (LivingEntity e : hit) hurt(p, e, dmg);
    }
    public static void sphere(ServerWorld w, Vec3d c, double r, ParticleEffect pe, int count) {
        Random rnd = new Random();
        for (int i = 0; i < count; i++) {
            Vec3d v = new Vec3d(rnd.nextGaussian(), rnd.nextGaussian(), rnd.nextGaussian()).normalize().multiply(r);
            w.spawnParticles(pe, c.x + v.x, c.y + v.y, c.z + v.z, 1, 0, 0, 0, 0.02);
        }
    }
    public static void blast(ServerWorld w, ServerPlayerEntity p, Vec3d pos, float power) {
        w.createExplosion(p, pos.x, pos.y, pos.z, power, World.ExplosionSourceType.TNT);
    }
    public static void bolt(ServerWorld w, Vec3d pos, boolean cosmetic) {
        LightningEntity l = EntityType.LIGHTNING_BOLT.create(w);
        if (l == null) return;
        l.refreshPositionAfterTeleport(pos); l.setCosmetic(cosmetic); w.spawnEntity(l);
    }
    public static void crater(ServerWorld w, Vec3d c, int r) {
        BlockPos o = BlockPos.ofFloored(c);
        for (BlockPos bp : BlockPos.iterate(o.add(-r, -r, -r), o.add(r, r, r))) {
            if (bp.getSquaredDistance(o) > r * r) continue;
            BlockState st = w.getBlockState(bp);
            if (!st.isAir() && st.getHardness(w, bp) >= 0) w.setBlockState(bp, Blocks.AIR.getDefaultState(), 3);
        }
    }
    public static void sound(ServerWorld w, Vec3d p, SoundEvent s) {
        w.playSound(null, p.x, p.y, p.z, s, SoundCategory.PLAYERS, 1.5f, 1f);
    }
}
