package com.villainascension;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.*;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.*;
import net.minecraft.world.World;

public class StoneItem extends Item {
    private final Ability ability;
    public StoneItem(Ability ability) { super(new Item.Settings().maxCount(1).rarity(Rarity.EPIC).fireproof()); this.ability = ability; }
    @Override public boolean hasGlint(ItemStack s) { return true; }
    @Override public TypedActionResult<ItemStack> use(World w, PlayerEntity p, Hand h) {
        if (!w.isClient && p instanceof ServerPlayerEntity sp) {
            ability.run().accept(sp); sp.sendMessage(net.minecraft.text.Text.literal(ability.name()), true);
            p.getItemCooldownManager().set(this, ability.cooldown());
        }
        return TypedActionResult.success(p.getStackInHand(h));
    }
}
