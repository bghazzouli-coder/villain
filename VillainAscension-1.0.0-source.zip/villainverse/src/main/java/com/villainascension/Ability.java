package com.villainascension;
import java.util.function.Consumer;
import net.minecraft.server.network.ServerPlayerEntity;
public record Ability(String name, int cooldown, Consumer<ServerPlayerEntity> run) {}
